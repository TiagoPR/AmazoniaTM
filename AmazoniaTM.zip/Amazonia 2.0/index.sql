CREATE INDEX fk_funcionario
ON tem (fk_Funcionario_Funcionario_ID);
CREATE INDEX fk_pedido
ON tem (fk_Pedido_ID_Pedido); 
CREATE INDEX fk_item_pedido
ON contem (fk_Item_Item_ID);

